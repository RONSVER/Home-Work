public enum Anniversaries {
    print_wedding ,
    paper_wedding,
    Leather_Wedding,
    linen_wedding,
    wooden_wedding,
    Castiron_weddings,
    Copper_weddings,
    Tin_wedding,
    faience_weddings,
    stannic_weddings,
    steel_wedding,
    write_the_correct_number

}

