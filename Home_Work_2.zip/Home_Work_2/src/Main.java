public class Main {
    public static void main(String[] args) {
        System.out.println("=======================");
        System.out.println("!!!Информация о людях!!!");
        System.out.println("=======================");
        System.out.println("Фамилия: Белов");
        System.out.println("");
        System.out.println("Имя: Александр");
        System.out.println("");
        System.out.println("Очество: Николаевич");
        System.out.println("");
        System.out.println("Возраст: 25 лет");
        System.out.println("");
        System.out.println("Рост:" + 1.75);
        System.out.println("-----------------------");

        System.out.println("-----------------------");
        System.out.println("Фамилия: Касл");
        System.out.println("");
        System.out.println("Имя: Фрэнсис");
        System.out.println("");
        System.out.println("Очество: Дэвид");
        System.out.println("");
        System.out.println("Возраст: 35 лет");
        System.out.println("");
        System.out.println("Рост:" + 1.90);
        System.out.println("-----------------------");

        System.out.println("-----------------------");
        System.out.println("Фамилия: Хиггинс");
        System.out.println("");
        System.out.println("Имя: Джаред");
        System.out.println("");
        System.out.println("Очество: Энтони");
        System.out.println("");
        System.out.println("Возраст: 21 лет");
        System.out.println("");
        System.out.println("Рост:" + 1.70);
        System.out.println("-----------------------");
        System.out.println("");
        System.out.println("===================================");
        System.out.println("!!!Вывод чисел и учение ключей!!!");
        System.out.println("===================================");
        System.out.println("");
        System.out.println("-----------------------");

        System.out.printf(
                "%s числа, %.2f, %.2f, а ещё есть %.2f", "у нас есть"
                , 3.444, 4.333, 5.444
        );

        System.out.println("");
        System.out.println("-----------------------");
        System.out.println("================================================");
        System.out.println("Вывод фигуры с помощью команд принт и принтлн");
        System.out.println("================================================");

        System.out.print(" -");
        System.out.print("-");
        System.out.print("-");
        System.out.println("");
        System.out.print("|   ");
        System.out.print("|   ");
        System.out.println("");
        System.out.print("|   ");
        System.out.print("|   ");
        System.out.println("");
        System.out.print(" -");
        System.out.print("-");
        System.out.print("-");











    }
}
