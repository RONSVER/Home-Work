public enum Snak {
    SNICKERS,
    BOUNTY,
    TWIX,
    MARS

}
