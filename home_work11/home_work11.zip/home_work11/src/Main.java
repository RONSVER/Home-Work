public class Main {
    public static void main(String[] args) {
        long lo = 1000L;
        byte k = (byte) lo;
        short j = (short) k;
        int c = (int) j;
        double e = c;

        System.out.println(e);
    }
}