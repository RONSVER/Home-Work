public class Main {
    public static void main(String[] args) {
        System.out.println(5 % 4);
        System.out.println(15 % 3);
        boolean x1 = 2 % 2 == 0;
        System.out.println("тру четное фалс не четное: " + x1);

        boolean x2 = 7 % 2 == 0;
        System.out.println("тру четное фалс не четное: " + x2);

        boolean x3 = 13 % 2 == 0;
        System.out.println("тру четное фалс не четное: " + x3);

        boolean x4 = 14 % 2 == 0;
        System.out.println("тру четное фалс не четное: " + x4);

        int f1 = 15 % 10;

        System.out.println(f1);
    }
}