public class Main {
    public static void main(String[] args) {
        int i1 = 5;
        int i2 = 7;
        long l1 = 9;
        long l2 = 10;
        double d1 = 74;
        double d2 = 44;
        float f1 = 25;
        float f2 = 56;

        int vivod1 = i1 + i2;
        long vivod2 = l1 + l2;
        long vivod3 = i1 + l1;
        float vivod4 = i1 + f1;
        double vivod5 = i1 + d1;
        double vivod6 = l1 + d1;
        System.out.println(vivod1);
        System.out.println(vivod2);
        System.out.println(vivod3);
        System.out.println(vivod4);
        System.out.println(vivod5);
        System.out.println(vivod6);
    }
}