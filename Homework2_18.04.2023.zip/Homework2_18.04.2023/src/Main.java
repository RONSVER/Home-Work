public class Main {


    public static String compressString(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }

        StringBuilder sb = new StringBuilder();
        char currentChar = str.charAt(0);
        int currentCharCount = 1;

        for (int i = 1; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c == currentChar) {
                currentCharCount++;
            } else {
                sb.append(currentChar);
                if (currentCharCount > 1) {
                    sb.append(currentCharCount);
                }
                currentChar = c;
                currentCharCount = 1;
            }
        }

        sb.append(currentChar);
        if (currentCharCount > 1) {
            sb.append(currentCharCount);
        }

        return sb.toString();
    }


    public static void main(String[] args) {
        String str = "AAABBBCCCDDEG";
        String compressedStr = compressString(str);
        System.out.println(compressedStr);


    }
}