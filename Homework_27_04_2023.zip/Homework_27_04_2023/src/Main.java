import java.util.Random;
import java.util.Scanner;



//Напишите аналог Random для генерации строк - StringRandom.
// В классе реализуйте набор публичных статических методов:
// первый метод генерирует слово заданной длины,
// состоящее из  английских букв (любой набор букв).
// Второй метод генерирует предложение из заданного количества разных слов.
// Третий метод генерирует текст из заданного количества разных предложений,
// разделяя предложения случайными знаками препинания из набора (. или ! или ? или …).
// В методе main сгенерируйте текст из 1000 предложений.
public class Main {
    public static void main(String[] args) {

        Random rnd = new Random();
        Scanner scn = new Scanner(System.in);
        System.out.println("задайте длину");
        int wordLength = scn.nextInt();
        String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
        int a = rnd.nextInt(0, ALPHABET.length());
        System.out.println(generateWord(ALPHABET, wordLength));
        System.out.println("предложение из заданного количества разных слов :");
        System.out.println(generateSentence(ALPHABET, wordLength));
        System.out.println("Текст из заданного количества разных предложений, разделяя предложения случайными знаками препинания :");
        System.out.println(generateTexts(ALPHABET, wordLength));
        //текст из 1000 предложений

        System.out.println("Текст из 1000 предложений: ");
        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < 1000; i++) {
            int sentenceLength = rnd.nextInt(2) + 1; // Генерируем случайную длину предложения
            for (int j = 0; j < sentenceLength; j++) {
                int wordLength1 = rnd.nextInt(4) + 1; // Генерируем случайную длину слова
                for (int k = 0; k < wordLength1; k++) {
                    char letter = (char) (rnd.nextInt(26) + 'a'); // Генерируем случайную букву из алфавита
                    stringBuilder.append(letter);
                }
            }
            stringBuilder.append(".");
        }
        System.out.println(stringBuilder.toString());
    }


    // метод, который генерирует слово, заданной длины
    public static String generateWord(String str, int wordLength) {
        Random rnd = new Random();
        StringBuilder word = new StringBuilder();
        for (int i = 0; i < wordLength; i++) {
            int rndNum = rnd.nextInt(0, str.length());
            word.append(str.charAt(rndNum));
        }
        return word.toString();
    }

    //метод, который генерирует предложение из заданного количества разных слов
    public static String generateSentence(String string, int textLength) {

        StringBuilder text = new StringBuilder();
        for (int i = 0; i < textLength; i++) {
            String word = "";
            Random random = new Random();
            for (int j = 0; j < random.nextInt(2, 8); j++) {
                int ranNum = random.nextInt(0, string.length());
                word = word + string.charAt(ranNum);
            }
            text.append(" ").append(word);
        }
        return text.toString();

    }

    //генерирует текст из заданного количества разных предложений, разделяя предложения случайными знаками препинания
    public static String generateTexts(String str1, int textLength) {
        char[] punctuation = {'.', '!', '?', '…'};
        Random r = new Random();
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < textLength; i++) {
            StringBuilder words = new StringBuilder();
            for (int j = 0; j < r.nextInt(5, 15); j++) {
                String word = generateWord(str1, r.nextInt(0, 10));
                words.append(" ").append(word);
            }
            text.append(words).append(punctuation[r.nextInt(0, punctuation.length)]);

        }
        return text.toString();

    }


}



