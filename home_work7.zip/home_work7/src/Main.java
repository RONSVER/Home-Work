public class Main {
    public static void main(String[] args) {
        byte f1 = 127;
        System.out.println(f1);
        f1++;
        System.out.println(f1);



    }
}