import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        int a = random.nextInt(999);
        System.out.println("сгенерированое число " + a);
        long b = random.nextLong(999);
        System.out.println("сгенерированое число " + b);
        int d = random.nextInt(999);
        System.out.println("сгенерированое число " + d);
        System.out.println("сумма сгенерированных чисел = " + (a + b + d));
        System.out.println("сумма сгенерированных чисел = " + a * b * d);


    }
}