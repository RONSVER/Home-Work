import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //1 Пользователь вводит число. Если число больше 0, то выполнить следующие операции:
        //
        //
        //умножить число на 2, если оно нечётное;
        //
        //прибавить к числу 5, если если оно заканчивается на 5 или 0.
        //Если число < 0, то взять его по модулю и разделить на 3.
        //Результат вычисления вывести в консоль.

        Scanner scanner = new Scanner(System.in);
        System.out.println("Проэкт 1");
        System.out.println("Введите цифру");
        int a = scanner.nextInt();

        if (a > 0 && a % 2 != 0) {
            System.out.println("*2: " + a * 2);
        }

        if ((a % 10 == 5 || a % 10 == 0) && a > 0) {
            System.out.println("+5: " + (a + 5));

        }

        if (a < 0) {
            System.out.println("Работа с модулем делим на 3" + Math.abs(a / 3));
        }


        //2 Пользователь вводит строку. Если строка начинается с цифры (0, 1, 2, 3, 4, 5, 6 , 7, 8, 9),
        // то вывести эту цифру в консоль.
        // Если строка начинается со знака _ или знака -, то вывести в консоль строку без этого знака.
        // Используйте методы startsWith, charAt и substring.
        System.out.println("Проэкт 2");
        System.out.println("Введите строку:");
        char c = scanner.next().charAt(0);
        String userStr = scanner.next();
        if (c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9') {
            System.out.println(c);
            return;
        }
        if (c == '-' || c == '_') {
            userStr.substring(1, userStr.length());
            
        }
        System.out.println(c);

        //3 Пользователь вводит два числа.
        //Если они не равны, то вывести в консоль их сумму, иначе вывести их произведение. Используйте тернарный оператор.
        System.out.println("Проэкт 3");
        System.out.println("Введите два числа: ");
        int u = scanner.nextInt();
        int b = scanner.nextInt();
        int d = u != b ? b + u : u;
        System.out.println(d);
        //4 С помощью Random сгенерируйте три числа.
        //Напишите программу, которая находит максимальное из них. Используйте тернарные операторы.
        System.out.println("Проэкт 4");
        Random random = new Random();
        int s1 = random.nextInt(999);
        int s2 = random.nextInt(999);
        int s3 = random.nextInt(999);
        int max = s1 > s2 ? (s1 > s3 ? s1 : s3 ): (s2 > s3 ? s2 : s3);
        System.out.println("Первое сгенерированое число: ");
        System.out.println(s1);
        System.out.println("Второе сгенерированое число: ");
        System.out.println(s2);
        System.out.println("Третье сгенерированое число: ");
        System.out.println(s3);
        System.out.println("Самое крупное сгенерированое число: ");
        System.out.println(max);
    }
}