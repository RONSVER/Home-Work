import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        // Проект 1. Двумерные массивы
        //1 Создайте двумерный массив и заполните его буквами русского алфавита.
        char[][] azbuka = new char[6][6];
        char init = 'А';
        char last = 'Я';
        for (int i = 0; i < azbuka.length; i++) {
            for (int j = 0; j < azbuka[i].length; j++) {
                azbuka[i][j] = init;
                init++;
                if (init > last) {
                    break;
                }
            }
            System.out.println(Arrays.deepToString(azbuka));
        }
        System.out.println();
        //2* (по желанию) Пусть в двумерном массиве N элементов. Заполните двумерный массив целыми числами от 1 до N по спирали.
        // Например,
        //01 02 03 04
        //12 13 14 05
        //11 16 15 06
        //10 09 08 07
        int n = 4; // размерность двумерного массива
        int[][] arr = new int[n][n]; // создание двумерного массива размером n x n
        int num = 1; // начальное число, которое нужно записать в первую ячейку массива
        int rowStart = 0, rowEnd = n - 1, colStart = 0, colEnd = n - 1; // индексы начала и конца заполняемой области

        while (num <= n * n) { // пока не заполнены все ячейки массива
            // заполняем верхнюю строку
            for (int i = colStart; i <= colEnd; i++) {
                arr[rowStart][i] = num; // записываем текущее число в ячейку массива
                num++; // увеличиваем число на 1
            }
            rowStart++; // перемещаем индекс начала строки вниз

            // заполняем правый столбец
            for (int i = rowStart; i <= rowEnd; i++) {
                arr[i][colEnd] = num; // записываем текущее число в ячейку массива
                num++; // увеличиваем число на 1
            }
            colEnd--; // перемещаем индекс конца столбца влево

            // заполняем нижнюю строку
            for (int i = colEnd; i >= colStart; i--) {
                arr[rowEnd][i] = num; // записываем текущее число в ячейку массива
                num++; // увеличиваем число на 1
            }
            rowEnd--; // перемещаем индекс конца строки вверх

            // заполняем левый столбец
            for (int i = rowEnd; i >= rowStart; i--) {
                arr[i][colStart] = num; // записываем текущее число в ячейку массива
                num++; // увеличиваем число на 1
            }
            colStart++; // перемещаем индекс начала столбца вправо
        }

        // выводим результат на экран
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(String.format("%02d ", arr[i][j])); // выводим значение ячейки массива на экран
            }
            System.out.println(); // переходим на новую строку
        }


    }
    
}
