import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Проэкт 1 ");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите трехзначное число: ");
        int a = scanner.nextInt();
        System.out.println(a/100);
        System.out.println(a/10%10);
        System.out.println(a%10);
    }
}