public class Main {
    public static void main(String[] args) {
      byte f = 1;
      short b = f;
      int l = b;
      long h = l;
      double k = h;

        System.out.println(k);
    }
}