public class Main {
    public static void main(String[] args) {
        int Anton = 31;
        int kostya = 60;
        int summa = Anton + kostya;
        System.out.println("вот что вышло: " + summa);

        int minus = Anton - kostya;
        System.out.println("вот что вышло: " + minus);

        int mult = Anton * kostya;
        System.out.println("вот что вышло: " + mult);

        int delenie = kostya / Anton;
        System.out.println("вот что вышло: " + delenie);

        int delenieost = kostya % Anton;
        System.out.println("вот что вышло c остатком: " + delenieost);
    }
}