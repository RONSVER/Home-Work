import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //3 Пользователь вводит строку. Разместите буквы в строке по алфавиту и выведите в консоль.
        System.out.println("Введите текст");
        Scanner scanner = new Scanner(System.in);
        String usrString = scanner.nextLine();
        char[] arrChar = usrString.toCharArray();
        Arrays.sort(arrChar);
        System.out.println(arrChar);
        System.out.println();
        System.out.println();

        //4 Пользователь вводит строку. Посчитайте количество слов в строке и выведите в консоль.
        //Разделителем между словами считать только пробел.
        //Если в строке есть слова, которые длиннее трёх символов, то вывести эти слова в консоль.

        // Считываем входную строку
        System.out.println("Введите строку");
        String usrString1 = scanner.nextLine();

        // Разделяем строку на слова по пробелам
        String[] strArray = usrString1.split(" ");

        int wordCount = strArray.length;
        System.out.println("Количество слов в строке: " + wordCount);

        // Выводим слова длиннее трех символов
        System.out.print("Слова длиннее трех символов: ");
        for (String word : strArray) {
            if (word.length() > 3) {
                System.out.print(word + " ");

            }

        }
    }
}