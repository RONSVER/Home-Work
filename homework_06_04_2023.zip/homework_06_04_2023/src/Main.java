import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // 1 уровень сложности: 1 n - номер дома, в котором Вы живёте (без учёта дробей, корпусов, строений и т.д).
        // Создайте массив целых чисел. Заполните
        //массив числами от 0 до n*10, выведите массив в консоль.
        int n = 3; // пример номера дома

        int[] arr1 = new int[(n + 1) * 10]; // создаем массив размером n*10

        for (int i = 0; i < arr1.length; i++) {
            arr1[i] = i; // заполняем массив значениями от 0 до n*10
            System.out.print(arr1[i] + " ");
        }

        System.out.println();
        System.out.println();
        //2 Создайте случайно заполненный числовой массив, выведите его в консоль.
        // Найдите максимальное по модулю число в массиве и выведите его в консоль.
        int[] arr = new int[10];
        Random rnd = new Random();
        System.out.println("Массив: ");
        for (int i = 0; i < arr.length; i++) {
            arr[i] = rnd.nextInt(-10, 21);
            System.out.print(arr[i] + " ");

        }

        int maxAbsValue = Math.abs(arr[0]);
        for (int i = 1; i < arr.length; i++) {
            if (Math.abs(arr[i]) > maxAbsValue) {
                maxAbsValue = Math.abs(arr[i]);
            }
        }
        System.out.println("Максимальное по модулю число: " + maxAbsValue);
        System.out.println(Arrays.toString(arr));

       



    }
}