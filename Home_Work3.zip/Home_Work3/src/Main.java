public class Main {
    static final char MALE = ('m');
    static final char FEMALE = ('f');
    public static void main(String[] args) {
        boolean kirilboolean = true;
        byte kirilbyte =  12;
        short kirilshorts = 1234;
        int kirilint = 123456789;
        long  kirillong = 1l;
        float kirilfloat = 1.2f;
        double kirildouble = 1.44;
        char kirilchar = MALE;
        System.out.println("kirilboolean:" + kirilboolean);
        System.out.println("kirilbyte:" + kirilbyte);
        System.out.println("kirilshorts:" + kirilshorts);
        System.out.println("kirilint:" + kirilint);
        System.out.println("kirillong:" + kirillong);
        System.out.println("kirilfloat:" + kirilfloat);
        System.out.println("kirildouble:" + kirildouble);
        System.out.println("kirilchar:" + kirilchar);
        kirilint = kirilint / 9;
        System.out.println(kirilint);
        kirilchar = FEMALE;
        System.out.println(kirilchar);
        kirilfloat = kirilfloat * 2;
        System.out.println(kirilfloat);

    }
}